package distribution;

public class ObjectID {
	private int id;
	public ObjectID(int i){
		setId(i);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
}
