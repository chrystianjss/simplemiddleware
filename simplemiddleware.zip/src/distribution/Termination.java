package distribution;


public class Termination {
	private Object result;
	
	public Termination(){};
	
	public Object getResult() {
		return result;
	}

	public void setResult(Object obj) {
		this.result = obj;
	}
}
